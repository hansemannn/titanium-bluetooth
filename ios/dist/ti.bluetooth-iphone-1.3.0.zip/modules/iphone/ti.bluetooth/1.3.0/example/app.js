// PLease check ios/example/app.js and android/example/app.js for examples! 🚀 
